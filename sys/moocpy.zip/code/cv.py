import cv2
import subprocess
import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
import subprocess
import json
from file import file
from paddleocr import PaddleOCR, draw_ocr

# from paddleocr import PPStructure,draw_structure_result,save_structure_res

# table_engine = PPStructure(show_log=True, image_orientation=True)
filePath = file.filePath
fileName = file.fileName

ocr = PaddleOCR(use_angle_cls=True, lang="en")  # need to run only once to download and load model into memory

os.chdir(r"" + filePath + '/data/' + fileName + '/Videos')
# v_path = '[2.1.1]--机器数及特点视频.mp4'
v_path = 'index.mp4'
image_save = './pic'
outFile = filePath + '/data/' + fileName + '/ocrResult.json'

cap = cv2.VideoCapture(v_path)
timeRate = 200  # 截取视频帧的时间间隔
c = 1

ocrResult = []

while True:
    ret, frame = cap.read()
    FPS = cap.get(5)  # 帧率
    if ret:
        frameRate = int(FPS) * timeRate  # 因为cap.get(5)获取的帧数不是整数，所以需要取整一下（向下取整用int，四舍五入用round，向上取整需要用math模块的ceil()方法）
        # print(frameRate)
        # 获取视频宽度

        frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))

        # 获取视频高度

        frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        if c % frameRate == 0:
            print(frame_height, frame_width)
            tp = {
                "num": c,
                "fps": FPS,
            }

            print("开始截取视频第：" + str(c) + " 帧")
            # print(frame)
            result = ocr.ocr(frame, cls=True)
            print(result)
            boxes = []  # [line[0] for line in result]
            txts = []  # [line[1][0] for line in result]
            scores = []  # [line[1][1] for line in result]
            for line in result[0]:
                # print(line)
                boxes.append(line[0])
                txts.append(line[1][0])
                scores.append(line[1][1])
            # box = np.reshape(np.array(boxes[0]), [-1, 1, 2]).astype(np.int64)
            # image = cv2.polylines(frame, [box], True, (255, 0, 0), 2)
            # cv2.imshow("img", image)
            # cv2.waitKey(0)
            # cv2.destroyAllWindows()
            # print(boxes[0])
            # print(box)
            tp['boxes'] = boxes
            tp['txts'] = txts
            tp['scores'] = scores
            tp['img'] = frame.tolist()
            ocrResult.append(tp)
        c = c + 1
        cv2.waitKey(0)
    else:
        print("所有帧都已经保存完成")
        break
cap.release()

# print(ocrResult)
# with open(outFile, 'w', encoding="utf-8") as fs:
#     json.dump(ocrResult, fs, ensure_ascii=False)
