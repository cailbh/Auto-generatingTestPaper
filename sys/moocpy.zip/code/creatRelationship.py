'''
coding:utf-8
@Software:PyCharm
@Time:2023/3/13 10:59
@Author:cailbh
@Introduce: 随机自创关系
'''
import time
import random

from file import file
import json
import time
from datetime import datetime, date

filePath = file.filePath
fileName = file.fileName

inputDir = r"" + filePath + "/data/" + fileName + "/case2_fin.json"

outRelFile = filePath + "/data/" + fileName + "/case2_fin_rel.json"
outFile = filePath + "/data/" + fileName + "/Fina.json"

with open(inputDir, "r", encoding="utf-8") as f:
    content = json.load(f)
    with open(outRelFile, "r", encoding="utf-8") as rf:
        relcontent = json.load(rf)
        # for c in content:
        #     print(c)
        basicRelNum = 8
        similarityRelNum = 3
        basicRel = relcontent['basicRel']
        similarityRel = relcontent['similarityRel']
        # for i in range(basicRelNum):
        #     a = random.randint(0, 42)
        #     b = random.randint(0, 42)
        #     if (a != b) & ([a, b] not in basicRel) & ([b, a] not in basicRel):
        #         basicRel.append([a, b])
        # for i in range(similarityRelNum):
        #     a = random.randint(0, 42)
        #     b = random.randint(0, 42)
        #     if (a != b) & ([a, b] not in basicRel) & ([b, a] not in basicRel):
        #         similarityRel.append([a, b])

        for r in similarityRel:
            print(r)
            for c in range(len(content)):
                if (content[c]['id'] == str(r[0])) & (r[1] not in content[c]['similarityRel']):
                    print(content[c]['id'], r[0])
                    content[c]['similarityRel'].append(str(r[1]))
                if (content[c]['id'] == str(r[1])) & (r[0] not in content[c]['similarityRel']):
                    content[c]['similarityRel'].append(str(r[0]))
        for r in basicRel:
            # print(r)
            for c in range(len(content)):
                # print(c['id'], )  # content[c]['id'])
                if (content[c]['id'] == str(r[0])) & (r[1] not in content[c]['basicRel']):
                    content[c]['basicRel'].append(str(r[1]))
                if (content[c]['id'] == str(r[1])) & (r[0] not in content[c]['basicRel']):
                    content[c]['basicRel'].append(str(r[0]))
        # rel = {
        #     "basicRel": basicRel,
        #     "similarityRel": similarityRel,
        # }
        finalL = content
        with open(outFile, 'w', encoding='utf-8') as fa:
            print(finalL)
            json.dump(finalL, fa, ensure_ascii=False)
        # with open(outRelFile, 'w', encoding='utf-8') as fs:
        #     json.dump(rel, fs, ensure_ascii=False)
