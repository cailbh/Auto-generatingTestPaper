"""
coding:utf-8
@Software:PyCharm
@Time:2023/3/7 21:02
@Author:cailbh
@Introduce: 处理自创数据
"""
import time
import random

from file import file
import json
import time
from datetime import datetime, date

filePath = file.filePath
fileName = file.fileName

inputDir = r"" + filePath + "/data/" + fileName + "/case2_fin.json"

outFile = filePath + "/data/" + fileName + "/fin3.json"
print(inputDir)
tt = '00:01:20'


def t2s(t):
    h, m, s = t.strip().split(":")
    return int(h) * 3600 + int(m) * 60 + int(s)


def s2t(seconds):
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    return "%02d:%02d:%02d" % (h, m, s)


print(t2s(tt), s2t(80))

with open(inputDir, "r", encoding="utf-8") as f:
    content = json.load(f)
    pre_father = ['root']
    pre_layout = '-1'
    pre_layout_id = '-1'
    pre_time = '00:00:00'
    for c in range(len(content)):
        content[c]['id'] = str(c)
        content[c]['type'] = "0"
        content[c]['timeSonId'] = str(c + 1)
        content[c]['timeFatherId'] = str(c - 1)
        # durTime = random.randint(6, 20)
        # typeNum = random.randint(2, int(durTime / 3))
        # preTypeTime = 0
        # typeObj = {"1": [], "2": [], "3": []}
        # for tNum in range(typeNum):
        #     typeDur = random.randint(1, int(durTime / typeNum))
        #     if tNum == typeNum - 1:
        #         typeDur = durTime - preTypeTime
        #     type = random.randint(1, 3)
        #     typeObj[str(type)].append([s2t(t2s(pre_time) + preTypeTime), s2t(t2s(pre_time) + preTypeTime + typeDur)])
        #     preTypeTime += typeDur
        # curTime = s2t(t2s(pre_time) + durTime)
        # content[c]['time'] = [pre_time, curTime]
        content[c]['attribute']['importance'] = random.randint(5, 20)
        content[c]['attribute']['relevance'] = random.randint(5, 20)
        content[c]['son'] = []
        content[c]['father'] = []
        content[c]['similarityRel'] = []
        content[c]['basicRel'] = []
        # content[c]['attribute']['expressions'] = typeObj
        # content[c]['attribute']['duration'] = random.randint(5, 20)
        # pre_time = curTime
        lay = content[c]['layout']
        if lay > pre_layout:
            content[c]['father'].append(pre_layout_id)
        elif lay == pre_layout:
            content[c]['father'].append(content[c - 1]['father'][0])
        elif lay == '0':
            content[c]['father'].append('-1')
        else:
            for x in range(1, c+1):
                if content[c - x]['layout'] == lay:
                    content[c]['father'].append(content[c - x]['father'][0])
                    break
        for x in range(1, c+1):
            if content[c - x]['id'] == content[c]['father'][0]:
                content[c - x]['son'].append(content[c]['id'])
                break

        pre_layout = content[c]['layout']
        pre_layout_id = content[c]['id']

    for c in range(len(content)):
        print(c, content[c]['id'], content[c]['son'])
        son = content[c]['son']
        time = content[c]['time']
        durTime = (t2s(time[0]) + t2s(time[1]))
        curTime = s2t(t2s(pre_time) + durTime)
        dur = t2s(time[1]) - t2s(time[0])
        print(time, t2s(time[1]), t2s(time[0]), dur)
        sons = [son]
        while len(sons) > 0:
            print('ss',sons)
            curSon = sons[len(sons) - 1]
            sons.pop()
            for s in curSon:
                # print(s)
                for x in range(len(content)):
                    if content[x]['id'] == s:
                        so = content[x]['son']
                        print(so)
                        if len(so) > 0:
                            sons.append(so)
                        stime = content[x]['time']
                        dur += t2s(stime[1]) - t2s(stime[0])
                        # print(stime, t2s(stime[1]), t2s(stime[0]), dur)
        content[c]['totalDuration'] = dur
    finalL = content
    with open(outFile, 'w', encoding='utf-8') as fs:
        json.dump(finalL, fs, ensure_ascii=False)
    # with open(outFile, 'w') as fs:
    #     json.dump(content, fs)
