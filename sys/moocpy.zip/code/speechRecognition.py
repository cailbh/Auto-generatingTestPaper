# import speech_recognition as sr
from paddlespeech.cli.asr.infer import ASRExecutor
asr = ASRExecutor()
result = asr(audio_file="zh.wav")
print(result)
# 我认为跑步最重要的就是给我带来了身体健康


from file import file
filePath = file.filePath
fileName = file.fileName


path = '[2.1.1]--机器数及特点视频.mp4'
r = sr.Recognizer()  # 调用识别器
harvard = sr.AudioFile(path)  # 导入语音文件

# 上下文管理器打开文件并读取其内容
with harvard as source:
    all_audio = r.record(source)  # 使用record()从文件中捕获数据

# 查看类型
print(type(all_audio))  # <class 'speech_recognition.AudioData'>

all_text = r.recognize_sphinx(all_audio)  # 识别输出
print(all_text)
# this they'll smell of old we're lingers it takes heat to
# bring out the odor called it restores health and zest
# case all the colt is fine with him couples all pastore
# my favorite is as full food is the hot cross mon


# 识别部分文件并输出
with harvard as source:
    # 分割视频文件   指定偏移量及持续时间
    audio = r.record(source, offset=4, duration=3)  # 从第4秒开始,持续时间3秒

text = r.recognize_sphinx(audio)  # 识别输出
print(text)  # it takes heat to bring out the odor
