from gensim.models import word2vec
import text2vec
from text2vec import Word2Vec
from file import file

filePath = file.filePath
fileName = file.fileName
# 文件所在文件夹
filedir = r"" + filePath + "/data/" + fileName

# input_path = filedir + "/pptResult1.txt"
w2vOutput_path = filedir + '/' + fileName + "word2vec.txt"
textNumOutput_path = filedir + '/' + fileName + "textNum.txt"
model = Word2Vec("w2v-light-tencent-chinese")
#
# num = 3
participleResultDir = r"" + filePath + "/data/" + fileName + "/resultjieba.txt"
#
file1 = open(participleResultDir, 'r', encoding='utf-8')
result = {}
for line in file1:
    if line.find("\t") >= 0:
        line = line.strip("\r\n").split("\t")
    else:
        line = line.strip("\r\n").split(" ")
        for l in line:
            if l not in result.keys():
                result[l] = 1
            else:
                result[l] = result[l] + 1

print(result)

w2vOutfile = open(w2vOutput_path, 'w')
textNumOutfile = open(textNumOutput_path, 'w')
print(result)
i = 0
print(w2vOutput_path)
for word in result:
    # if result[word] > 1:
        print(word)
        textNumOutfile.write(str(i) + " " + word + "\n")
        embeddings = model.encode(word)
        print(type(embeddings), embeddings.shape, embeddings)
        w2vOutfile.write(str(i) + ' ')
        for e in embeddings:
            # print(i)
            w2vOutfile.write(str(e) + ' ')
        w2vOutfile.write('\n')
        i = i + 1
# char = '卡'
# result = text2vec.encode(char)
# print(type(result))
# print(char, result)

# word = '银行卡'
# print(word, text2vec.encode(word))
#
# a = '卡'
# # emb = text2vec.encode(a)
# # print(a, emb)
# # 中文词向量模型(word2vec)，中文字面匹配任务和冷启动适用
# # compute_emb(w2v_model)
# embeddings = model.encode(a)
# print(type(embeddings), embeddings.shape, embeddings)
