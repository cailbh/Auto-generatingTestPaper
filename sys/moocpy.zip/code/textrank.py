import jieba
from file import file
import re
import jieba.posseg as psg
import codecs
from textrank4zh import TextRank4Keyword, TextRank4Sentence

filePath = file.filePath
fileName = file.fileName
# 文件所在文件夹
filedir = r"" + filePath + "/data/" + fileName

input_path = filedir + "/result.txt"
output_path = filedir + "/textrankDict.txt"
stopwords_path = filePath + "/stopwords.txt"

# 设置停用词,把停用词放进列表
# print('start read stopwords data.')
stopwords = []
with open(stopwords_path, 'r') as f:
    for line in f:
        if len(line) > 0:
            stopwords.append(line.strip())

#
# tr4w.analyze(text=text, lower=True, window=2)  # py2中text必须是utf8编码的str或者unicode对象，py3中必须是utf8编码的bytes或者str对象
text = codecs.open(input_path, 'r', 'utf-8').read()
f = open(output_path, 'w', encoding='utf-8')
print(text)
# tr4w = TextRank4Keyword(allow_speech_tags=['n', 'nr', 'nrfg', 'ns', 'nt', 'nz'])
tr4w = TextRank4Keyword()

tr4w.analyze(text=text, lower=True, window=2)  # py2中text必须是utf8编码的str或者unicode对象，py3中必须是utf8编码的bytes或者str对象

print(text)

print('关键词：')
for item in tr4w.get_keywords(500, word_min_len=2):
    print(item.word)
    f.write(item.word + "\n")

print()
print('关键短语：')
for phrase in tr4w.get_keyphrases(keywords_num=100, min_occur_num=1):
    print(phrase)
    f.write(phrase + '\n')

for words in tr4w.words_no_stop_words:
    print('/'.join(words))

# 读取文件数据，分词，并输出到文件
#     with open(input_path, 'r', encoding='utf-8') as f:
#         for line in f:
#             print(line)
#             tr4w.analyze(text=line, lower=True, window=2)  # py2中text必须是utf8编码的str或者unicode对象，py3中必须是utf8编码的bytes或者str对象
#             for item in tr4w.get_keywords(20, word_min_len=1):
#                 print(item.word, item.weight)
#             print('关键短语：')
#             for phrase in tr4w.get_keyphrases(keywords_num=20, min_occur_num=2):
#                 print(phrase)
#             # s = tokenizer(line.strip())
#             # o.write(" ".join(s) + "\n")
