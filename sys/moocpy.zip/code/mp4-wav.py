from moviepy.editor import AudioFileClip

filename = "PrinciplesComputer"
filePath = 'D:\study\storyline\python-LDA-main\python-LDA-main'
path = filePath + "/data/" + filename + "/1.4.1.mp4"
resultPath = filePath + "/data/" + filename + "/1.4.1.wav"
# 导入视频
my_audio_clip = AudioFileClip(path)
# 提取音频并保存
my_audio_clip.write_audiofile(resultPath)
