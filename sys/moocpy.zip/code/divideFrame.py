"""
coding:utf-8
@Software:PyCharm
@Time:2023/3/4 17:36
@Author:caiLbh
@Introduce: 根据字数划分帧节
"""

from file import file
import json
import numpy as np
import math
from text2vec import Word2Vec
from scipy import spatial

import gensim

filePath = file.filePath
fileName = file.fileName
# model = gensim.models.KeyedVectors.load_word2vec_format('../GoogleNews-vectors-negative300.bin', binary=True)
# model = Word2Vec("w2v-light-tencent-chinese")
# print(model.similarity('woman', 'man'))
dirPath = r"" + filePath + "/data/" + fileName + "/ocrResult.json"

outFile = filePath + "/data/" + fileName + "/frameDivide.json"


def get_len(texts):
    l = 0
    for t in texts:
        l = l + len(t)
    return l


with open(dirPath, "r", encoding="utf-8") as f:
    content = json.load(f)
    pre_len = 100000
    finalL = []
    c = 0
    i = -1
    for frame in content:
        i = i + 1
        cur_len = get_len(frame['txts'])
        # print(frame['num'], cur_len-pre_len,len(frame['txts']), frame['txts'])
        frame['clu'] = c
        diffValue = cur_len - pre_len
        pre_len = cur_len
        print(diffValue, abs(diffValue) / (cur_len + 0.1))
        if (cur_len == 0) | ((diffValue < 0) & (abs(diffValue) / (cur_len + 0.1) > 0.5)):
            print(frame['num'], cur_len - pre_len, len(frame['txts']), frame['txts'])
            print(content[i - 1]['num'], cur_len - pre_len, len(content[i - 1]['txts']), content[i - 1]['txts'])
            finalL.append(content[i - 1])
            c = c + 1
        # frame['vec'] = avg_feature_vector(frame['txts'], model)
    with open(outFile, 'w',encoding='utf-8') as fs:
        json.dump(finalL, fs, ensure_ascii=False)
