# import jiagu
#
# text = '''
# 该研究主持者之一、波士顿大学地球与环境科学系博士陈池（音）表示，“尽管中国和印度国土面积仅占全球陆地的9%，但两国为这一绿化过程贡献超过三分之一。考虑到人口过多的国家一般存在对土地过度利用的问题，这个发现令人吃惊。”
# NASA埃姆斯研究中心的科学家拉玛·内曼尼（Rama Nemani）说，“这一长期数据能让我们深入分析地表绿化背后的影响因素。我们一开始以为，植被增加是由于更多二氧化碳排放，导致气候更加温暖、潮湿，适宜生长。”
# “MODIS的数据让我们能在非常小的尺度上理解这一现象，我们发现人类活动也作出了贡献。”
# NASA文章介绍，在中国为全球绿化进程做出的贡献中，有42%来源于植树造林工程，对于减少土壤侵蚀、空气污染与气候变化发挥了作用。
# 据观察者网过往报道，2017年我国全国共完成造林736.2万公顷、森林抚育830.2万公顷。其中，天然林资源保护工程完成造林26万公顷，退耕还林工程完成造林91.2万公顷。京津风沙源治理工程完成造林18.5万公顷。三北及长江流域等重点防护林体系工程完成造林99.1万公顷。完成国家储备林建设任务68万公顷。
# '''
#
# keywords = jiagu.keywords(text, 50) # 关键词
# print(keywords)
import json
import copy
from file import file
from functools import reduce

filePath = file.filePath
fileName = file.fileName
#
# num = 3
# dirPath = r"" + filePath + "/data/" + fileName + "/full_data.csv"
caseDirPath = r"" + filePath + "/data/" + fileName + "/owid-covid-latest.json"
dirPath = r"" + filePath + "/data/" + fileName + "/result.json"
outFile = filePath + "/data/" + fileName + "/result1.json"
# f = open(caseDirPath, 'r')
# i = 0
# dateList = []
# tap = []
# for line in f:
#     l = line.split(',')
#     # print(l[0])
#     if i > 0:
#         dateList.append(l[0])
#         for n in range(len(l)):
#             v = l[n]
#             if (l[n] == '') | (l[n] == '\n'):
#                 v = 0
#             # if l[0] in tap[n]['case']:
#             #     tap[n]['case'][l[0]].append()
#             # else:
#             tap[n]['case'][l[0]] = str(v).split('\n')[0]
#
#     elif i == 0:
#         for n in l:
#             tap.append({'name': n, 'case': {}})
#         print(tap)
#
#     i = i + 1
# print(tap)
# print(dateList)
# dataTmp = []
# dateList.append('2023-02-18')
# dateList.append('2023-02-19')
# for date in dateList:
#     tp = {"date": date,
#           "total_vaccinations": 0,
#           "people_vaccinated": 0,
#           "daily_vaccinations": 0,
#           "total_vaccinations_per_hundred": 0,
#           "people_vaccinated_per_hundred": 0,
#           "daily_vaccinations_per_million": 0,
#           "daily_people_vaccinated": 0,
#           "daily_people_vaccinated_per_hundred": 0}
#     dataTmp.append(tp)

gdpl = {}
with open(caseDirPath, "r", encoding="utf-8") as fc:
    gdps = json.load(fc)
    # print(gdps)
    for i in gdps:
        print(i,gdps[i])
        gdpl[gdps[i]['location']] = gdps[i]['gdp_per_capita']

with open(dirPath, "r", encoding="utf-8") as f:
    content = json.load(f)
    # print(content)
    for c in content:
        tpData = c['data']
        # d = reduce(lambda pre, cur: cur if cur['name'] == c['country'] else pre, tap, None)
        # print(d)
        case = 0
        # if d != None:
            # print(c['country'], d)
        for i in c['data']:
            if c['country'] in gdpl:
                i['gdp_per_capita'] = gdpl[c['country']]
            else:
                i['gdp_per_capita'] = 100
        # tplist = copy.deepcopy(dataTmp)
        # for i in tpData:
        # if 'daily_vaccinations' in i:
        #     d['daily_vaccinations'] = i['daily_vaccinations']
        # if 'daily_people_vaccinated' in i:
        #     d['daily_people_vaccinated'] = i['daily_people_vaccinated']
        # i['case'] =
        # c['data'] = tplist
    with open(outFile, 'w') as fs:
        json.dump(content, fs)
