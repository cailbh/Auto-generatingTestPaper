import jieba
from file import file
import re
import jieba.posseg as psg

filePath = file.filePath
fileName = file.fileName
# 文件所在文件夹
filedir = r"" + filePath + "/data/" + fileName

input_path = filedir + "/result.txt"
output_path = filedir + "/resultjieba.txt"
stopwords_path = filePath + "/stopwords.txt"
dict_path = filedir + "/textrankDict.txt"
# 设置停用词,把停用词放进列表
# print('start read stopwords data.')
stopwords = []
with open(stopwords_path, 'r') as f:
    for line in f:
        if len(line) > 0:
            stopwords.append(line.strip())


# 定义分词函数
def tokenizer(s):
    jieba.load_userdict(dict_path)
    jieba.initialize()
    # jieba.enable_paddle()
    # try:
    #     stopword_list = open(stop_file, encoding='utf-8')
    # except:
    #     stopword_list = []
    #     print("error in stop_file")
    words = []
    cut = psg.cut(s)

    flag_list = ['n', 'nz', 'vn','nr','an','ns','i','nt','nz',]
    for se_word in cut:
        word = re.sub(u'[^\u4e00-\u9fa5]', '', se_word.word)
        print(word)
        find = 0
        if word not in stopwords:
            if len(word) > 1:
                if find == 0 and se_word.flag in flag_list:
                    words.append(word)
    return words


# 读取文件数据，分词，并输出到文件
with open(output_path, 'w', encoding='utf-8') as o:
    with open(input_path, 'r', encoding='utf-8') as f:
        for line in f:
            s = tokenizer(line.strip())
            o.write(" ".join(s) + "\n")
