# 去除时间行保留文字脚本
import json

from file import file

filePath = file.filePath
fileName = file.fileName

participleResultDir = r"" + filePath + "/data/" + fileName + "/" + fileName + ".txt"
outFile = "" + filePath + "/data/" + fileName + "/" + fileName + ".json"
file1 = open(participleResultDir, 'r', encoding='utf-8')
print(participleResultDir)
i = 0
j = 1
result = []
tp = {
    'time': [],
    'text': []
}
for line in file1:
    if line.find("\t") >= 0:
        line = line.strip("\r\n").split("\t")
    else:
        line = line.strip("\r\n").split(" ")
    if i == 1:
        print(111, line)
        tp['time'].append(line[0])
        if len(line)>1:
            tp['time'].append(line[2])
    if i == 2:
        print(222, line)
        for l in line:
            tp['text'].append(l)
    if i == 3:
        if line[0] != '':
            for l in line:
                tp['text'].append(l)
    if line[0] == str(j):
        print(11111, j)
        j += 1
        print(line)
        i = 0
        result.append(tp)
        tp = {
            'time': [],
            'text': []
        }
    # if i == 5:
    #     i = 0
    i = i + 1

# print(result)
# f = open(filePath + "oriData.txt", 'w')  # 若是'wb'就表示写二进制文件
# # j = 0
# # tm = []
# #
# # for i in idMat:
# #     f.write(i + ",")
# #     f.write(str(X_tsne[j][0]) + "," + str(X_tsne[j][1]) + "\n")
# #     tm.append({"id": i, "x": float(X_tsne[j][0]), "y": float(X_tsne[j][1])})
# #     j = j + 1
# # f.close()
# for r in result:
#     for l in r:
#         print(l)
#         f.write(l)
#     f.write("\n")
with open(outFile, 'w', encoding='utf-8') as fs:
    json.dump(result, fs, ensure_ascii=False)
