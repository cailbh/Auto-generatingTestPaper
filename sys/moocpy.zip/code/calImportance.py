"""
coding:utf-8
@Software:PyCharm
@Time:2023/3/7 21:02
@Author:cailbh
@Introduce: 处理自创数据
"""
import time
import random

from file import file
import json
import time
from datetime import datetime, date

filePath = file.filePath
fileName = file.fileName

inputDir = r"" + filePath + "/data/" + fileName + "/case2_fin.json"
textFile = "" + filePath + "/data/" + fileName + "/" + fileName + ".json"
RelFile = filePath + "/data/" + fileName + "/case2_fin_rel.json"

outFile = filePath + "/data/" + fileName + "/fin11.json"
# outPFile = filePath + "/data/" + fileName + "/keys.json"
print(inputDir)
tt = '00:01:20'


def t2s(t):
    h, m, s = t.strip().split(":")
    return int(h) * 3600 + int(m) * 60 + int(s)


def s2t(seconds):
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    return "%02d:%02d:%02d" % (h, m, s)


txts = []
keys = []
with open(textFile, "r", encoding="utf-8") as f:
    texts = json.load(f)
    for t in texts:
        for w in t['text']:
            txts.append(w)

print(txts)
with open(inputDir, "r", encoding="utf-8") as f:
    content = json.load(f)
    for c in range(len(content)):  # random.randint(5, 20)
        sons = content[c]['son']
        simRel = content[c]['similarityRel']
        basRel = content[c]['basicRel']
        content[c]['attribute']['importance'] = len(simRel)+len(basRel)+len(sons)  # random.randint(5, 20)
        content[c]['attribute']['relevance'] = len(simRel)+len(basRel)+len(sons)
        # content[c]['father'] = []
        # name = content[c]['name'].split(" ")
        # print(name)
        # i = 0
        # jg = 0
        # cnt = 0
        # for w in txts:
        #     if i >= len(name) - 1:
        #         cnt += 1
        #         i = 0
        #     if w == name[0]:
        #         i = 1
        #         jg = 1
        #     if jg == 1:
        #         print(w, i, name[0])
        #         if w == name[i]:
        #             jg = 1
        #             i += 1
        #         else:
        #             jg = 0
        # print(cnt)
        #
    finalL = content
    with open(outFile, 'w', encoding='utf-8') as fs:
        json.dump(finalL, fs, ensure_ascii=False)
