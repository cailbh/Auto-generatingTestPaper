from gensim.models import word2vec
import text2vec
from text2vec import Word2Vec
from file import file
import numpy as np
from cname import color
import pandas as pd
from sklearn.manifold import TSNE
from sklearn.manifold import SpectralEmbedding
from sklearn.cluster import KMeans
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import AffinityPropagation

from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt

cNames = color.cnameList
filePath = file.filePath
fileName = file.fileName
# 文件所在文件夹
filedir = r"" + filePath + "/data/" + fileName

input_path = filedir + '/' + fileName + "word2vec.txt"

textNum_path = filedir + '/' + fileName + "textNum.txt"
#

file1 = open(input_path, 'r', encoding='utf-8')
fileText = open(textNum_path, 'r', encoding='gbk')
dataMat = []
idMat = []
result = []
i = 0
for line in file1.readlines():
    i = i + 1
    line = line.strip().split(" ")
    idMat.append(line[0])
    del line[0]
    dataMat.append(line)

texts = {}
j = 0
for line in fileText.readlines():
    line = line.strip().split(" ")
    print(line)
    texts[j] = line[1]
    j = j + 1

print(texts)

X = np.array(dataMat)

X_tn = TSNE(n_components=2).fit_transform(X)

# X_tn = SpectralEmbedding(n_components=2).fit_transform(X)
x_tn_scal = (StandardScaler().fit_transform(X_tn))
print(x_tn_scal)
kNum=15

kmeans = AffinityPropagation(damping=0.75,max_iter=200,convergence_iter=15,copy=True,preference=None,affinity='euclidean',verbose=False).fit(x_tn_scal)
# kmeans = DBSCAN(eps=0.5,min_samples=5,metric='euclidean',algorithm='auto',leaf_size=30,p=None,n_jobs=1).fit(x_tn_scal)
# kmeans = KMeans(n_clusters=kNum,random_state=0).fit(x_tn_scal)
labels = kmeans.labels_
#### ###########
# inertia = []
# sil = []
# for k in range(2,20):
#     kmeans = KMeans(n_clusters=k, random_state=0).fit(x_tn_scal)
#     inertia.append(np.sqrt(kmeans.inertia_))
#     sil.append(silhouette_score(x_tn_scal,kmeans.labels_))
#
# plt.plot(range(2,20),sil,'o-')
# plt.show()
################
k = 0
plt.rcParams["font.sans-serif"] = ["SimHei"]
# cNames =['red','green','blue']
for point in X_tn:
    plt.scatter(point[0], point[1],c=cNames[labels[k]+8])

    plt.text(point[0], point[1], texts[k], fontsize=12)
    k = k + 1

plt.show()

# w2vOutfile = open(w2vOutput_path, 'w')
# textNumOutfile = open(textNumOutput_path, 'w')
# print(result)
# i=0
# print(w2vOutput_path)
# for word in result:
#     print(word)
#     textNumOutfile.write(str(i)+" "+word+"\n")
#     embeddings = model.encode(word)
#     print(type(embeddings), embeddings.shape, embeddings)
#     w2vOutfile.write(str(i)+' ')
#     for e in embeddings:
#         # print(i)
#         w2vOutfile.write(str(e)+' ')
#     w2vOutfile.write('\n')
#     i=i+1
