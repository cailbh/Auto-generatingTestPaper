"""
coding:utf-8
@Software:PyCharm
@Time:2023/3/6 13:10
@Author:cailbh
@Introduce: 根据关键帧的ppt提取关键信息
"""
import cv2
from file import file
import json
import numpy as np
from text2vec import Word2Vec
from scipy import spatial
import math
import gensim

filePath = file.filePath
fileName = file.fileName
# model = gensim.models.KeyedVectors.load_word2vec_format('../GoogleNews-vectors-negative300.bin', binary=True)
# model = Word2Vec("w2v-light-tencent-chinese")
# print(model.similarity('woman', 'man'))
dirPath = r"" + filePath + "/data/" + fileName + "/ocr-vec-div.json"

outFile = filePath + "/data/" + fileName + "/ppt-graph.json"


def getColorMath(rgbA, rgbB):
    x1 = rgbA[0]
    x2 = rgbB[0]
    y1 = rgbA[1]
    y2 = rgbB[1]
    z1 = rgbA[2]
    z2 = rgbB[2]
    return math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) + (z1 - z2) * (z1 - z2))


def getDetail(txts, boxes, scores, img):
    # print(txts)
    # print(scores)
    # print(boxes)
    result = []
    preTp = {}
    for i in range(len(txts)):
        tp = {}
        score = scores[i]
        if score > 0.5:
            box = boxes[i]
            x = (box[0][0] + box[3][0]) / 2
            y = (box[0][1] + box[1][1]) / 2
            height = ((box[3][1] - box[0][1]) + (box[2][1] - box[1][1])) / 2
            width = ((box[1][0] - box[0][0]) + (box[2][0] - box[3][0])) / 2
            midY = (box[0][1] + box[1][1] + box[2][1] + box[3][1]) / 4
            tp['txt'] = txts[i]
            tp['x'] = x
            tp['y'] = y
            tp['height'] = height
            tp['width'] = width
            tp['midY'] = midY
            # tp = img[int(y):int(y + height), [int(x), int(x + width)]]
            # print('lllll', len(img), len(img[0]), img[0:10, 0:10])
            # tpp = img[0:360, 0:100]
            # imgs = np.asarray(tpp, dtype=np.uint8)
            # # img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
            # cv2.imshow("lena", imgs)
            # cv2.waitKey(1000)
            # print(midY, x, y, height, width)
            jg = 0
            diffCount = 0
            d = 0
            for r in range(int(y), int(y + height)):
                preC = [255, 255, 255]
                stp = 0
                if (int(x) - 15) > 0:
                    stp = int(x) - 15
                for l in range(stp, int(x)):
                    if l > stp:
                        curC = img[r][l]
                        de = getColorMath(preC, curC)
                        preC = curC

                        if de > 30:
                            diffCount += 1
                            d = de
                    else:
                        preC = [255, 255, 255]
            if (diffCount % 2 == 0) & (diffCount != 0):
                jg = 1
            # print(diffCount, jg, d, txts[i])
            tp['jgCircle'] = jg
            if jg == 0:
                if preTp == {}:
                    result.append(tp)
                else:
                    preTp = tp
                    # result.append(tp)
                    # print(result[len(result) - 1])
                    result[len(result) - 1]['txt'] += ' ' + (tp['txt'])
            else:
                preTp = tp
                result.append(tp)
            # result.append(tp)
            # print(txts[i], boxes[i])
    return result


with open(dirPath, "r", encoding="utf-8") as f:
    content = json.load(f)
    # print(content)
    i = 0
    for tp in content:
        # print(p)
        # if i == 1:
        boxes = tp['boxes']
        txts = tp['txts']
        scores = tp['scores']
        img_list = tp['img']
        # print(1111, img_list, len(img_list), img_list[277][77])
        img = np.asarray(img_list, dtype=np.uint8)
        # img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
        cv2.imshow("lena", img)
        cv2.waitKey(1000)
        res = getDetail(txts, boxes, scores, img_list)
        print(res)
        i += 1
