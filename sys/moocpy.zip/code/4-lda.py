from typing import TextIO
# import Ipython
import pyLDAvis as pyLDAvis
import pyLDAvis.gensim_models
import jieba, os, re
from gensim import corpora, models, similarities
import logging
from file import file

filePath = file.filePath
fileName = file.fileName

logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)
num = 3
participleResultDir = r"" + filePath + "/data/" + fileName + "/pptResultjieba.txt"
# 读取处理好的文本
outfilename = open(participleResultDir, 'r', encoding='utf-8')

# 构建词频矩阵
# train是列表套列表，
train = [[word.strip() for word in line.split()] for line in outfilename]
dictionary = corpora.Dictionary(train)
# dictionary.filter_extremes(no_below=5)  # 去掉频次小于5的词

# corpus[0]: [(0, 1), (1, 1), (2, 1), (3, 1), (4, 1),...]
# corpus是把每条事件ID化后的结果，每个元素是事件中的每个词语，在字典中的ID和频率
corpus = [dictionary.doc2bow(text) for text in train]
print('特征数目: %d' % len(dictionary))
print(dictionary)
print('文档数目: %d' % len(corpus))

print(corpus)

# 训练LDA模型
num_topics = 4
eval_every = None
temp = dictionary[0]
id2word = dictionary.id2token

lda = models.LdaModel(corpus=corpus, id2word=dictionary.id2token, num_topics=num_topics, iterations=400, chunksize=2000,
                      passes=20, random_state=None)
topic_list = lda.print_topics(4)
print("4个主题的单词分布为：\n")
for topic in topic_list:
    print(topic)

# signal_paper_corpus = dictionary.doc2bow(["大家好", "我们", "学习"])
# 利用第五步得到的lda模型，得到文章在该lda模型中，在每个主题下的数值
# paper_distribution = lda(signal_paper_corpus)
for text in train:
    print(text)
    print(dictionary.doc2bow(text))
    signal_paper_corpus = dictionary.doc2bow(text)
    paper_distribution = lda[signal_paper_corpus]
    print(paper_distribution)
print(signal_paper_corpus)

# lda.save('lda.model')

# num_topics = 10
# model_list = []
# perplexity_values = []  # 困惑度
# coherence_values = []   # 一致性
# for topic in range(0, num_topics):
#     print("主题数量：", topic + 1)
#     lda_model = models.LdaModel(corpus=corpus, num_topics=topic + 1, id2word=dictionary.id2token, chunksize=2000,
#                                 passes=20, iterations=400, random_state=None)
#     model_list.append(lda_model)
#     # print(train)
#     # coherencemodel = models.CoherenceModel(model=lda_model, texts=train, dictionary=dictionary, coherence='c_v')
#     # coherence_values.append(coherencemodel.get_coherence())
#     #
#     perplexity_values.append(lda_model.log_perplexity(corpus))
# print(perplexity_values)
# print(coherence_values)

# 可视化
data = pyLDAvis.gensim_models.prepare(lda, corpus, dictionary, sort_topics=False, mds='mmds')
#pyLDAvis.save_html(data, 'lda_pass10.html')
pyLDAvis.show(data)
pyLDAvis.save_html(data, 'lda_pass10.html')
pyLDAvis.display(data)
# 图中圆圈代表不同的主题,圆圈的大小代表主题的重要程度,圆圈越大表示该主题对应数据来说更重要。如果圆圈之间有相互重叠则说明它们所代表的主题有相似之处。
