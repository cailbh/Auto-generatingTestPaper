class file():
    fileName = 'testEn'# "PrinciplesComputer"
    filePath = 'D:\Cailibuhong\moocpy'
