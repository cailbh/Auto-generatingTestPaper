"""
coding:utf-8
@project:mooc
@Software:PyCharm
@Time:2023/3/4 17:22
@Author:caiLbh
@Introduce: 处理ocr后的文件，得到每一帧ocr后的文本向量表示,根据相似度划分帧节
"""

from file import file
import json
import numpy as np
from text2vec import Word2Vec
from scipy import spatial
import math
import gensim

filePath = file.filePath
fileName = file.fileName
# model = gensim.models.KeyedVectors.load_word2vec_format('../GoogleNews-vectors-negative300.bin', binary=True)
model = Word2Vec("w2v-light-tencent-chinese")
# print(model.similarity('woman', 'man'))
dirPath = r"" + filePath + "/data/" + fileName + "/ocrResult.json"

outFile = filePath + "/data/" + fileName + "/ocr-vec-div.json"


def avg_feature_vector(words, model):
    # words = sentence.split()
    feature_vec = np.zeros((200,), dtype='float32')
    n_words = 0
    for word in words:
        # if word in index2word_set:
        n_words += 1
        feature_vec = np.add(feature_vec, model.encode(word))
    if n_words > 0:
        feature_vec = np.divide(feature_vec, n_words)
    return feature_vec.tolist()


with open(dirPath, "r", encoding="utf-8") as f:
    content = json.load(f)
    # print(content)
    i = -1
    c = 0
    finalL = []
    pre_vec = np.zeros((200,), dtype='float32')
    for frame in content:
        i = i + 1
        frame['vec'] = avg_feature_vector(frame['txts'], model)
        cur_vec = frame['vec']
        sim = 1 - spatial.distance.cosine(pre_vec, cur_vec)
        pre_vec = cur_vec
        if sim < 0.996:
            print(2222222, content[i-1]['num'], sim, math.pow(sim, 2), content[i-1]['txts'])
            print(1111111, frame['num'], sim, math.pow(sim, 2), frame['txts'])
            content[i-1]['clu'] = c
            c=c+1
            finalL.append(content[i-1])

    with open(outFile, 'w', encoding='utf-8') as fs:
        json.dump(finalL, fs, ensure_ascii=False)
    # with open(outFile, 'w') as fs:
    #     json.dump(content, fs)
